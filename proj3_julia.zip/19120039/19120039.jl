using CSV
using DataFrames
iris = CSV.read("iris.csv", DataFrame)

# SỬ DỤNG HÀM RANDOM ĐỂ XOÁ CÁC DÒNG NGẪU NHIÊN
function split_iris(data)
    train_iris = data
    test_iris = data
    for i in 1:floor(Int8, 1/3 * size(train_iris, 1))
        ran = rand(1:20)
        delete!(train_iris, ran)
    end
    for i in 1:floor(Int8, (2/3 * size(test_iris, 1) + 5))
        ran = rand(1:20)
        delete!(test_iris, ran)
    end
    return train_iris, test_iris
end

train_iris, test_iris = split_iris(iris)
print(train_iris, test_iris)

# HÀM KIỂM TRA XEM CÁC DATA TRONG DATAFRAME CHỈ CÓ MỘT VARIETY
function check_pure(data)
    name_column = data[!, last(names(data))]
    unique_value = unique(name_column)
    if length(unique_value) == 1
        return true
    end
    return false
end
#print(check_pure(iris[iris."petal.width" .< 0.8,:]))
#test = iris[(iris."petal_width" .> 0.8) .&  (iris."petal_width" .< 2),:]

# HÀM TÌM LUẬT XÉT TRONG DATA NÀY VARIETY NÀO CHIẾM NHIỀU NHẤT
function classify(data)
    label_name = last(names(data))
    variety = unique(data[!,label_name])
    temp = []
    for i in variety
        count = 0
        for j in data[!,label_name]
            if ( i == j)
                count = count + 1
            end
        end
        append!(temp, count)
    end
    index_max = findall(x-> x == maximum(temp), temp)
    #print(temp)
    classification = variety[index_max]
    return classification
end
#print(classify(test))

# TÁCH CÁC CỘT TRONG DATAFRAME VÀO DICT ĐỂ XỬ LÝ
function potential_split_value(data)
    potential_splits = Dict()
    num_cols = size(data, 2)
    for index_cols in 1:(num_cols - 1)
        potential_splits[index_cols] = []
        values = data[!, index_cols]
        unique_values = unique(values)
        potential_split = []
        for index in 1:length(unique(values))
            if index != 1
                current = unique_values[index]
                previous = unique_values[index - 1]
                append!(potential_split,(current + previous) / 2)
                
            end
        end
        push!(potential_splits, index_cols => potential_split)
    end
    return potential_splits
end
#print(potential_split_value(iris))


# HÀM TÁCH DATAFRAME DỰA VÀO VALUE CUTOFF VÀ CỘT CẦN THẢO MÃN NGƯỠNG CUTOFF
function split_data(data, split_column, split_value)
    split_column_values = data[:, split_column]
    #print("name", names(data)[split_column])
    #print(names(data)[split_column])
    data_below = data[split_column_values .<= split_value, :]
    data_above = data[split_column_values .> split_value, :]

    return data_below, data_above
end
#a,b = split_data(iris, 4, 0.55)
#print(a)
#print(b)

# HÀM TÍNH ENTROPY
function calculate_entropy(data)
    label_name = last(names(data))
    variety = unique(data[!, label_name])
    #print(variety)
    temp = []
    for i in variety
        count = 0
        for j in data[!,label_name]
            if ( i == j)
                count = count + 1
            end
        end
        append!(temp, count)
    end
    entropy = 0
    for i in temp
        p = i / sum(temp)
        entropy = entropy + ((p) * (-log(2, p)))
    end
    return entropy
end
#print(calculate_entropy(a))

#HÀM TÍNH ENTROPY TỔNG THỂ
function calculate_overall_entropy(data_below, data_above)
    
    n = size(data_below, 2) + size(data_above, 2)
    p_data_below = size(data_below, 2) / n
    p_data_above = size(data_above, 2) / n

    overall_entropy =  (p_data_below * calculate_entropy(data_below) 
                      + p_data_above * calculate_entropy(data_above))
    
    return overall_entropy
end

# HÀM XÉT CÁC CỘT VÀ TÌM RA CỘT VÀ NGƯỠNG VALUE CUTOFF ĐỂ ENTROPY LÀ NHỎ NHẤT
function determine_best_split(data, potential_splits)
    best_split_column = 0
    best_split_value = 0
    overall_entropy = 9999
    for column_index in keys(potential_splits)
        #print(potential_splits[column_index])
        for value in potential_splits[column_index]
            data_below, data_above = split_data(data, column_index, value)
            current_overall_entropy = calculate_overall_entropy(data_below, data_above)
            if current_overall_entropy <= overall_entropy
                overall_entropy = current_overall_entropy
                best_split_column = column_index
                best_split_value = value
            end
        end
    end
    return best_split_column, best_split_value
end
potential_splits = potential_split_value(iris)
#print(potential_splits[4])
#print(determine_best_split(iris, potential_splits))


# THUẬT TOÁN CÂY QUYẾT ĐỊNH - ID3
function decision_tree_algorithm(df, counter)
    
    if counter == 0
        data = values(df)
    else
        data = df
    end
    
    # Kiểm tra xem dữ liệu có thuộc về cùng 1 variety
    if check_pure(data)
        classification = classify(data)
        return classification

    else 
        counter += 1
        header = names(data)

        # Tính toán tìm ra chỉ số của cột và value để chia 2 bảng
        potential_splits = potential_split_value(data)
        split_column, split_value = determine_best_split(data, potential_splits)
        data_below, data_above = split_data(data, split_column, split_value)
        
        # Khởi tạo node con
        feature_name = header[split_column]
        question = string(feature_name, " <= ", split_value)
        sub_tree = Dict(question => [])
        
        # Gắn 2 node là 2 câu trả lời nối vào node vừa khởi tạo
        yes_answer = decision_tree_algorithm(data_below, counter)
        no_answer = decision_tree_algorithm(data_above, counter)
        
        if yes_answer == no_answer
            sub_tree = yes_answer
        else
            push!(sub_tree[question], yes_answer)
            push!(sub_tree[question], no_answer)
            #print(sub_tree[question], "\n")
            #merge!(sub_tree, sub_tree[question])
        end
        return sub_tree
    end
end

Tree = decision_tree_algorithm(train_iris, 0)

# HÀM ÁP DỤNG LUẬT CỦA CÂY QUYẾT ĐỊNH VÀO 1 DÒNG DỮ LIỆU
function classify_apply(row, Tree)
    question = []
    for i in keys(Tree)
        question = i
        
    end

    feature_name, comparison_operator, value = split(question, " ")
    #print(split(question, " "),"\n\n")
    
    if row[feature_name] <= parse(Float16,value)
        answer = Tree[question][1]
    else
        answer = Tree[question][2]
    end
    
    if isa(answer, Dict) == false
        
        return answer
    
    else
        residual_tree = answer
        #print("residual_tree    ", residual_tree)
        return classify_apply(row, residual_tree)
    end
end


# Hàm tính độ chính xác của luật vừa tạo ra
function count_accuracy(iris_test)
    temp_compare_1 = iris_test[!, last(names(iris_test))]
    temp_compare_2 = []
    
    #print("temp_1",temp_compare_1)
    for i in 1:size(iris_test, 1)
        result = classify_apply(iris_test[i, :], Tree)
        #print("\n\n\n", result, "r4esult\n\n")
        append!(temp_compare_2, result)
    end
    
    count = 0
    for i in 1:length(temp_compare_2)
        if (temp_compare_1[i] == temp_compare_2[i])
            count = count + 1
        end
    end

    percent = (count / length(temp_compare_2)) * 100
    return percent
end

# HÀM CHÍNH IN RA KẾT QUẢ
percent = count_accuracy(test_iris)
print("\n\n","=====================================", "\n\n")
print("DECISION TREE: \n\n", Tree, "\n\n")
print("DO CHINH XAC LA: ", percent, "\n\n")
# NOTE: DO EM SỬ DỤNG HÀM RANDOM ĐỂ LẤY MẪU NGẪU NHIÊN BẤT KỲ TỪ TẬP IRIS NÊN TỶ LỆ CHÍNH XÁC
#       CÙNG VỚI CÂY QUYẾT ĐỊNH SẼ THAY ĐỔI QUA TỪNG LẦN DEBUG
#===================================HẾT=======================================================